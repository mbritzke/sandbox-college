# Exercício 6

## Alunos
- Marlon Baptista de Quadros
- Matheus Britzke

NOTA PS